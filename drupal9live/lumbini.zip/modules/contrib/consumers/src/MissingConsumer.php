<?php

namespace Drupal\consumers;

class MissingConsumer extends \Exception {}
