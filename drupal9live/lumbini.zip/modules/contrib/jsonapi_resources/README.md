# JSON:API Resources

This module let's you define custom resources at routes of your choice that use existing resource types. This is useful
for defining routes that return resource objects based on context like the currently authenticated user instead of a
route parameter (e.g. a UUID)
